module.exports = {
  '100': {
    Desc: 'Continue',
    LongDesc: 'クライアントはリクエストを継続できます。サーバがリクエストの最初の部分を受け取り、まだ拒否していないことを示します。 例として、クライアントがExpect 100 continueヘッダをつけたリクエストを行い、それをサーバが受理した場合に返されます。',
  },
  '101': {
    Desc: 'Switching Protocols',
    LongDesc: 'サーバはリクエストを理解し、遂行のためにプロトコルの切替えを要求している場合に返されます。',
  },
  '102': {
    Desc: 'Processing',
    LongDesc: 'WebDAVの拡張ステータスコードです。処理が継続されて行われていることを示しています。',
  },
  '103': {
    Desc: 'Early Hints',
    LongDesc: '最終的なレスポンスヘッダが確定する前に、予想されるヘッダを伝達します。Linkレスポンスヘッダと組み合わせて、関連するリソースの先読み・プッシュ配信に利用することが想定されています。',
  },
  '200': {
    Desc: "OK",
    LongDesc: "リクエストは成功し、レスポンスとともに要求に応じた情報が返されます。ブラウザでページが正しく表示された場合は、ほとんどがこのステータスコードを返しています。",
  },
  '202': {
    Desc: "Created",
    LongDesc: "リクエストは完了し、新たに作成されたリソースのURIが返されます。例えば、PUTメソッドでリソースを作成するリクエストを行ったとき、そのリクエストが完了した場合に返されます。",
  },
  '300': {
    Desc: "Found",
    LongDesc: "リクエストしたリソースが一時的に移動されているときに返される。Locationヘッダに移動先のURLが示されている。元々はMoved Temporarily、一時的に移動した、という意味であり、リクエストしたリソースが一時的にそのURLに存在せず、別のURLにある場合に使用するステータスコードでしたが、例えば掲示板やWikiなどで投稿後にブラウザを他のURLに転送したいときにもこのコードが使用されるようになったため、302はFoundになり、新たに303・307が作成されました。",
  },
  '404': {
    Desc: "Not Found",
    LongDesc: "リソースが見つかりませんでした。単に、アクセス権がない場合などにも使用されます。",
  },
  '500': {
    Desc: "Internal Server Error",
    LongDesc: "サーバ内部にエラーが発生した場合に返されます。例えば、CGIとして動作させているプログラムに文法エラーがあったり、設定に誤りがあった場合などに返されます。",
  },
  '501': {
    Desc: "Not Implemented",
    LongDesc: "実装されていないメソッドを使用した場合に返されます。例えば、WebDAVが実装されていないサーバに対してWebDAVで使用するメソッド（MOVEやCOPY）を使用した場合に返されます。",
  },
  '502': {
    Desc: 'Bad Gateway',
    LongDesc: 'ゲートウェイ・プロキシサーバは不正な要求を受け取り、これを拒否した場合に返されます。',
  },
  '503': {
    Desc: 'Service Unavailable',
    LongDesc: 'サービスが一時的に過負荷やメンテナンスで使用不可能である場合に返されます。例えば、アクセスが殺到して処理不能に陥った場合に返されます。',
  },
  '504': {
    Desc: 'Gateway Timeout',
    LongDesc: 'ゲートウェイ・プロキシサーバはURIから推測されるサーバからの適切なレスポンスがなくタイムアウトした場合に返されます。',
  },
  '505': {
    Desc: 'HTTP Version Not Supported',
    LongDesc: 'リクエストがサポートされていないHTTPバージョンである場合に返されます。',
  },
  '506': {
    Desc: 'Variant Also Negotiates',
    LongDesc: 'Transparent Content Negotiation in HTTPで定義されている拡張ステータスコード。',
  },
  '507': {
    Desc: 'Insufficient Storage',
    LongDesc: 'WebDAVの拡張ステータスコードです。リクエストを処理するために必要なストレージの容量が足りない場合に返されます。',
  },
  '508': {
    Desc: 'Loop Detected',
    LongDesc: 'WebDAVの拡張ステータスコードです。ループを検出した場合に返されます。',
  },
  '509': {
    Desc: 'Bandwidth Limit Exceeded',
    LongDesc: 'そのサーバに設定されている帯域幅（転送量）を使い切った場合に返されます。',
  },
  '510': {
    Desc: 'Not Extended',
    LongDesc: 'HTTP Extension Frameworkで定義されている拡張ステータスコードです。拡張できない場合に返されます。',
  },
  '511': {
    Desc: 'Network Authentication Required',
    LongDesc: 'ネットワークに対する認証が必要な場合に返されます。キャプティブポータルでの使用を意図しており、RFC 6585 で規定されています。',
  },
};